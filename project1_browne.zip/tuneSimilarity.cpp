#include <string>
using namespace std;
double tuneSimilarity(string tune1, string tune2)
{
    //variable initailizaion 
    double score = 0; 
    double matchNote = 0;
    double matchComp = 0;
    double nonMatch = 0;
    // finds if they are not equal length
    if (tune1.length() != tune2.length())
        {
            return 0;
        }
        //loops the funtion and sets i to every other position 
    for (int i = 0; i < tune1.length(); i +=2)
    {
        // finds the number of 
        if (tune1.substr(i,2) == tune2.substr(i,2))
        {
            matchComp++;
        }
        if (tune1[i] == tune2[i])
        {
            matchNote++;
        }
        else if ((tune1[i] != tune2[i]) && (tune1[i+1] != tune2[i+1]))
        {
            nonMatch++;
        }
        
    }
    score = (matchNote / (tune1.length()/2));
    score += matchComp;
    score -= nonMatch;
    return score;