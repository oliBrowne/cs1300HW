#include <string>
using namespace std;

bool isValidNote(string note)
{
    bool noteCheck = false;
    // checks if it is within the appropiate ranges
    if (note[0] > 64 && note[0] < 72 && note[1] > 47 && note[1] < 58 && note[2] == 0 )
    {
        noteCheck = true;
    }
    return noteCheck;
}