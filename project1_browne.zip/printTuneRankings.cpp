#include <iostream>
#include <string>
#include <cassert>
#include <iomanip>
using namespace std; 

double tuneSimilarity(string tune1, string tune2)
{
    //variable initailizaion 
    double score = 0; 
    double matchNote = 0;
    double matchComp = 0;
    double nonMatch = 0;
    // finds if they are not equal length
    if (tune1.length() != tune2.length())
        {
            return 0;
        }
        //loops the funtion and sets i to every other position 
    for (int i = 0; i < tune1.length(); i +=2)
    {
        // finds the number of 
        if (tune1.substr(i,2) == tune2.substr(i,2))
        {
            matchComp++;
        }
        if (tune1[i] == tune2[i])
        {
            matchNote++;
        }
        else if ((tune1[i] != tune2[i]) && (tune1[i+1] != tune2[i+1]))
        {
            nonMatch++;
        }
        
    }
    score = (matchNote / (tune1.length()/2));
    score += matchComp;
    score -= nonMatch;
    return score;
}
double bestSimilarity(string input , string target)
{
    double testScore = -50 ;
    double highScore = -50 ;
    if (input.length() < target.length())
    {
        return 0;
    }
    for (int i = 0; i   < input.length() - target.length() + 1; i += 2)
    {
        
        testScore = tuneSimilarity(input.substr(i,target.length()), target);
        if ((testScore) > (highScore))
        {
            highScore = testScore;
        }



    }
    return highScore;
}
void printTuneRankings(string tune1, string tune2, string tune3, string target)
{
    //variable int
    double score1 = -50000;
    double score2 = -50000;
    double score3 = -50000;
    //positions
    string f1 = "Tune 1";
    string f2 = "Tune 2";
    string f3 = "Tune 3";
    //similarity
        score1 = bestSimilarity(tune1, target);
        score2 = bestSimilarity(tune2, target);
        score3 = bestSimilarity(tune3, target);

        // if funtions to  determine order
    if (score1 > score2 && score1 > score3)
    {
        f1 = "Tune 1";
        if (score2  > score3 )
        {
            f2 = "Tune 2";
            f3 = "Tune 3";
        }
        else if (score3 > score2)
        {
            f2 = "Tune 3";
            f3 = "Tune 2";
        }
        else if (score3 == score2)
        {
            f2 = "Tune 2";
            f3 = "Tune 3";
        }
        else;
    }
    else if (score2 > score1 && score2 > score3)
    {
        f1 = "Tune 2";
        if (score1  > score3 )
        {
            f2 = "Tune 1";
            f3 = "Tune 3";
        }
        else if (score3 > score1)
        {
            f2 = "Tune 3";
            f3 = "Tune 1";
        }
        else if (score3 == score1)
        {
            f2 = "Tune 1";
            f3 = "Tune 3";
        }
        else;
    }    

    else if (score3 > score2 && score3 > score1)
    {
        f1 = "Tune 3";
        if (score2  > score1 )
        {
            f2 = "Tune 2";
            f3 = "Tune 1";
        }
        else if (score1 > score2)
        {
            f2 = "Tune 1";
            f3 = "Tune 2";
            
        }
        else if (score1 == score2)
        {
            f2 = "Tune 1";
            f3 = "Tune 2";
        }
        else;
    }
    //if they areequal to things
    else if (score1 == score3)
    {
        f2 = "Tune 3";
        f3 = "Tune 2";
    }
    else if (score1 == score2)
    {
        f2 = "Tune 2";
        f3 = "Tune 3";
    }
    if (score1 == score3 && score1 == score2)
    {
        f1 = "Tune 1";
        f2 = "Tune 2";
        f3 = "Tune 3"; 
    }
    
    //cout funtion
    cout << "1) " << f1 << ", 2) " << f2 << ", 3) " << f3 << endl;
    
}