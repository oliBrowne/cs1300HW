#include <iostream>
#include <string>
#include <cassert>
#include <iomanip>
using namespace std;

bool isValidNote(string note)
{
    bool noteCheck = false;
    
    if (note[0] > 64 && note[0] < 72 && note[1] > 47 && note[1] < 58 && note[2] == 0 )
    {
        noteCheck = true;
    }
    return noteCheck;
}
bool isValidTune(string tune)
{
    bool tuneCheck = 1; 
    //if (tune.length() % 2 == 0)
    //{
        for ( int i = 0; i < tune.length(); i += 2)
        {
            if (tuneCheck == true)
            {
            string tuney = tune.substr(i,2); 
            tuneCheck = isValidNote(tuney);
            }
            

        }
    
    //}
    return tuneCheck;
}
int numValidNotes(string note)
{
     
    int validNotes = 0;
    for(int i = 0; i < note.length(); i++)
    {
        string tuney = note.substr(i,2);
        if (isValidNote(tuney) == true) 
        {
            validNotes++;
        }
    
    }
    return validNotes;
}

double tuneSimilarity(string tune1, string tune2)
{
    //variable initailizaion 
    double score = 0; 
    double matchNote = 0;
    double matchComp = 0;
    double nonMatch = 0;
    // finds if they are not equal length
    if (tune1.length() != tune2.length())
        {
            return 0;
        }
        //loops the funtion and sets i to every other position 
    for (int i = 0; i < tune1.length(); i +=2)
    {
        // finds the number of 
        if (tune1.substr(i,2) == tune2.substr(i,2))
        {
            matchComp++;
        }
        if (tune1[i] == tune2[i])
        {
            matchNote++;
        }
        else if ((tune1[i] != tune2[i]) && (tune1[i+1] != tune2[i+1]))
        {
            nonMatch++;
        }
        
    }
    score = (matchNote / (tune1.length()/2));
    score += matchComp;
    score -= nonMatch;
    return score;
}
double bestSimilarity(string input , string target)
{
    double testScore = -50 ;
    double highScore = -50 ;
    if (input.length() < target.length())
    {
        return 0;
    }
    for (int i = 0; i   < input.length() - target.length() + 1; i += 2)
    {
        
        testScore = tuneSimilarity(input.substr(i,target.length()), target);
        if ((testScore) > (highScore))
        {
            highScore = testScore;
        }



    }
    return highScore;
}
void printTuneRankings(string tune1, string tune2, string tune3, string target)
{
    double score1 = -50000;
    double score2 = -50000;
    double score3 = -50000;
    string f1 = "Tune 1";
    string f2 = "Tune 2";
    string f3 = "Tune 3";
    //funtion call
        score1 = bestSimilarity(tune1, target);
        score2 = bestSimilarity(tune2, target);
        score3 = bestSimilarity(tune3, target);
        

    
        
     // conditionals for paths   
    if (score1 > score2 && score1 > score3)
    {
        f1 = "Tune 1";
        if (score2  > score3 )
        {
            f2 = "Tune 2";
            f3 = "Tune 3";
        }
        else if (score3 > score2)
        {
            f2 = "Tune 3";
            f3 = "Tune 2";
        }
        else if (score3 == score2)
        {
            f2 = "Tune 2";
            f3 = "Tune 3";
        }
        else;
    }
    else if (score2 > score1 && score2 > score3)
    {
        f1 = "Tune 2";
        if (score1  > score3 )
        {
            f2 = "Tune 1";
            f3 = "Tune 3";
        }
        else if (score3 > score1)
        {
            f2 = "Tune 3";
            f3 = "Tune 1";
        }
        else if (score3 == score1)
        {
            f2 = "Tune 1";
            f3 = "Tune 3";
        }
        else;
    }    

    else if (score3 > score2 && score3 > score1)
    {
        f1 = "Tune 3";
        if (score2  > score1 )
        {
            f2 = "Tune 2";
            f3 = "Tune 1";
        }
        else if (score1 > score2)
        {
            f2 = "Tune 1";
            f3 = "Tune 2";
            
        }
        else if (score1 == score2)
        {
            f2 = "Tune 1";
            f3 = "Tune 2";
        }
        else;
    }
    else if (score1 == score3)
    {
        f2 = "Tune 3";
        f3 = "Tune 2";
    }
    else if (score1 == score2)
    {
        f2 = "Tune 2";
        f3 = "Tune 3";
    }
    if (score1 == score3 && score1 == score2)
    {
        f1 = "Tune 1";
        f2 = "Tune 2";
        f3 = "Tune 3"; 
    }
    
    
    cout << "1) " << f1 << ", 2) " << f2 << ", 3) " << f3 << endl;
    
}

int main()
{
	int menu;
	//---
	string case1tune;
	string case1tune2;
	//---
	string case2tune;
	string case2target;
	//---
	string case3tune1;
	string case3tune2;
	string case3tune3;
	string case3target;
	cout << setprecision(2) << fixed;
	do
	{
    	cout << "--- Menu ---" << endl
    	<< "1. Calculate similarity between two tunes." << endl
    	<< "2. Calculate best similarity between two tunes of potentially different lengths." << endl
    	<< "3. Print three input tunes in order from most to least similar to the target tune." << endl
    	<< "4. Exit." << endl << "Please enter your choice (1 - 4):" << endl;
   	 
    	cin >> menu;
    
	switch(menu)
	{
    	case 1:
         	// loop for tune valility
        	
        	            	cout << "Please enter the first tune:" << endl;
            do
        	{
            	getline(cin >> ws,case1tune);
            	isValidTune(case1tune);
            	if (isValidTune(case1tune) == false)
            	{
             	cout << "Invalid input. Please enter a tune in valid SPN:" << endl;
            	}
       	 
        	}
        	while (isValidTune(case1tune) == false);
        	// loop for tune valility
        	
        	 cout << "Please enter the second tune:" << endl;
        	   do
        	{
            	getline(cin >> ws,case1tune2);
            	isValidTune(case1tune2);
            	if (isValidTune(case1tune2) == false)
            	{
             	cout << "Invalid input. Please enter a tune in valid SPN:" << endl;

            	}
       	 
        	}
        	while (isValidTune(case2tune) == false);

        	cout << "The similarity score is " << tuneSimilarity(case1tune, case1tune2) << endl;


           	 
    	break;
    	// -----------------------------------------------
    	case 2:
    	// loop for tune valility
        	
        	cout << "Please enter the input tune:" << endl;
        	do
        	{
            	
            	getline(cin >> ws, case2tune);
            	isValidTune(case2tune);
            	if (isValidTune(case2tune) == false)
            	{
             	cout << "Invalid input. Please enter a tune in valid SPN:" << endl;

            	}
        	}
        	while (isValidTune(case2tune) == false);
        	// loop for target valility
        	
        	cout << "Please enter the target tune:" << endl;
        	do
        	{
            	
            	getline(cin >> ws, case2target);
            	isValidTune(case2target);
            	if (isValidTune(case2target) == false)
            	{
             	cout << "Invalid input. Please enter a tune in valid SPN:" << endl;

            	}
        	}
        	while (isValidTune(case2target) == false);
        	cout << "The best similarity score is: " << bestSimilarity(case2tune, case2target) << endl;
       	 

    	break;
    	// ------------------------------------------------
    	case 3:
        	cout << "Please enter the first tune:" << endl;
        	do
        	{
            	
            	getline(cin >> ws, case3tune1);
            	isValidTune(case3tune1);
            	if (isValidTune(case3tune1) == false)
            	{
             	cout << "Invalid input. Please enter a tune in valid SPN:" << endl;

            	}
        	}
        	while (isValidTune(case3tune1) == false);
       	 
       	 cout << "Please enter the second tune:" << endl;
        	do
        	{
            	
            	getline(cin >> ws, case3tune2);
            	isValidTune(case3tune2);
            	if (isValidTune(case3tune2) == false)
            	{
             	cout << "Invalid input. Please enter a tune in valid SPN:" << endl;

            	}
        	}
        	while (isValidTune(case3tune2) == false);
       	 
       	 cout << "Please enter the third tune:" << endl;
        	do
        	{
            	
            	getline(cin >> ws, case3tune3);
            	isValidTune(case3tune3);
            	if (isValidTune(case3tune3) == false)
            	{
             	cout << "Invalid input. Please enter a tune in valid SPN:" << endl;

            	}
        	}
        	while (isValidTune(case3tune3) == false);
       	 
       	 cout << "Please enter the target tune:" << endl;
        	do
        	{
            	
            	getline(cin >> ws, case3target);
            	isValidTune(case3target);
            	if (isValidTune(case3target) == false)
            	{
             	cout << "Invalid input. Please enter a tune in valid SPN:" << endl;

            	}
        	}
        	while (isValidTune(case3target) == false);
        	printTuneRankings (case3tune1, case3tune2, case3tune3, case3target);
    	break;
    	// exit funtion
    	case 4:
    
        	cout << "Goodbye!" << endl;
        	return 0;
        	break;
    	// invalid menu opperation
    	default:
    	cout << "Invalid Input." << endl;

	}
    
	}
	while (menu != 4);
}
