#include <string>
using namespace std;
bool isValidNote(string note)
{
    bool noteCheck = false;
    
    if (note[0] > 64 && note[0] < 72 && note[1] > 47 && note[1] < 58 && note[2] == 0 )
    {
        noteCheck = true;
    }
    return noteCheck;
}
int numValidNotes(string note)
{
    // 
    int validNotes = 0;
    for(int i = 0; i < note.length(); i++)
    {
        string tuney = note.substr(i,2);
        if (isValidNote(tuney) == true) 
        {
            validNotes++;
        }
    
    }
    return validNotes;
}