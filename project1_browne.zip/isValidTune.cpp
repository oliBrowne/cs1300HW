#include <string>
using namespace std;
bool isValidNote(string note)
{
    bool noteCheck = false;
    
    if (note[0] > 64 && note[0] < 72 && note[1] > 47 && note[1] < 58 && note[2] == 0 )
    {
        noteCheck = true;
    }
    return noteCheck;
}
bool isValidTune(string tune)
{
    bool tuneCheck = 1; 
    //scans code if formatting is correct for every position
        for ( int i = 0; i < tune.length(); i += 2)
        {
            if (tuneCheck == true)
            {
            // finds each note pair
            string tuney = tune.substr(i,2); 
            tuneCheck = isValidNote(tuney);
            }
            

        }
    
    //}
    return tuneCheck;
}