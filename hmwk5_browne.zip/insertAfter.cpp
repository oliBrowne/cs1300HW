#include <iostream>
#include <iomanip>
using namespace std;

bool insertAfter(string inputStrings[], int numElements, int size, int index , string stringToInsert)
{// special case
    if (numElements == size || index >= size)
    {
        return 0;
    }
    else;
    {
        //loop de loopp
        for (int i = size; i < index + 1; i--)
        {///puts is one affter
            inputStrings[i] = inputStrings[i+1];
        
        }
        inputStrings[index + 1] = stringToInsert;
    }
    return inputStrings;
}
string printArray(string input[],int size)
{
    for(int i = 0; i < size; i++)
    {
        cout << input[i] << endl;
    }
}
int main()
{
    test case 1
int size = 5;
string inputStrings[size] = {"pikachu", "meowth", "snorlax"};
int numElements = 3;
int index = 2;
string stringToInsert = "clefairy";
// result contains the value returned by insertAfter
bool result = insertAfter(inputStrings, numElements, size, index, stringToInsert);
// print result
cout << "Function returned value: "<< result << endl;
// print array contents
printArray(inputStrings, numElements+result);
}