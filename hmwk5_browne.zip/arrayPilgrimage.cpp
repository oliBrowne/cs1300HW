#include <iostream>
using namespace std;

int main ()
{
    int dist[10];
    for (int i = 0; i < 10; i++){
        dist[i] = 5 + i;
        cout << dist[i] << endl;
    }
    string city[5] = {"Boulder", "NYC", "LA", "Chicago", "Houston"};
    for (int i = 0; i < 5; i++)
    {
        cout << city[i] << endl;
    }
    int seq[100];
    for (int i = 1; i <= 100; i++ )
    {
         seq[i] = i * 6;
         cout << seq[i] << endl;
    }
    char al[56];
    for (int i = 0; i < 26; i+=1)
    {
       al[i] = 65 + i;
       al[i+1] = 97 + i;
       cout << al[i] << endl;
       cout << al[i+1] << endl;
       
    }

}