#include <iostream>
#include <iomanip>
using namespace std;

double min(double arr[], int arr_size)
{
    double minScore = 100000;
    for (int i = 0; i < arr_size; i++)
    {
        if (arr[i] < minScore)
        {
            minScore = arr[i];
        }
    }
    return minScore;
}
double sum(double arr[], int arr_size)
{
    double total = arr[0];
    for (int i = 1; i <= arr_size; i++)
    {
        total += arr[i];
    }

return total;

}
double average(double arr[], int arr_size)
{
    double total = arr[0];
    for (int i = 1; i <= arr_size; i++)
    {
        total += arr[i];
    }

    return total/arr_size;


}
int main()
{
    
    double arr[3] = {1.24, 5.68, 3.456};

cout << "Min: " << fixed << setprecision(3)<< min(arr, 3) << endl;
cout << "Sum: " << fixed << setprecision(3) << sum(arr, 3) << endl;
cout << "Avg: " << fixed << setprecision(3) << average(arr, 3) << endl;
}