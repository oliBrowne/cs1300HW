#include <iostream>
#include <iomanip>
#include <cassert>

int zeroesToFives(int arr[], int arr_size)
{
	int count = 0;
	//loops through input array
	for(int i = 0; i < arr_size; i++) 
	{ 
		if(arr[i] == 0) //if an element is zero, set it to five
		{ 
    			arr[i] = 5;
			count++;
		}
	}
	return count;
}
int main()
{
    //test pass
    int test1_arr[10] = {0, 1, 2,3,4,5,6,7,8,9};
    zeroesToFives(test1_arr, 10);
    assert(test1_arr[0] == 5);
    assert(test1_arr[1] == 1);
    assert(test1_arr[2] == 2);
    assert(test1_arr[3] == 3);
    assert(test1_arr[4] == 4);
    assert(test1_arr[5] == 5);
    assert(test1_arr[6] == 6);
    assert(test1_arr[7] == 7);
    assert(test1_arr[8] == 8);
    assert(test1_arr[9] == 9);
//test pass
    int test2_arr[3] = {0,0,0};
    zeroesToFives(test1_arr, 3);
    assert(test2_arr[0] == 5);
    assert(test2_arr[1] == 5);
    assert(test2_arr[2] == 5);
//test pass
    int test3_arr[3] = {99999,56678,0};
    zeroesToFives(test1_arr, 3);
    assert(test3_arr[0] == 99999);
    assert(test3_arr[1] == 56678);
    assert(test3_arr[2] == 0);
//test fail
    int test4_arr[3] = {0,0,0};
    zeroesToFives(test1_arr, 3);
    assert(test4_arr[0] == 5);
    assert(test4_arr[1] == 1);
    assert(test4_arr[2] == 2);
//test fail
    int test5_arr[3] = {98665,765,234};
    zeroesToFives(test1_arr, 3);
    assert(test5_arr[0] == 5);
    assert(test5_arr[1] == 1);
    assert(test5_arr[2] == 2);
//test fail
    int test6_arr[3] = {-876,45,-1};
    zeroesToFives(test1_arr, 3);
    assert(test6_arr[0] == 5);
    assert(test6_arr[1] == 1);
    assert(test6_arr[2] == 2);
//test pass
    int test7_arr[3] = {1,56,987};
    zeroesToFives(test1_arr, 3);
    assert(test7_arr[0] == 1);
    assert(test7_arr[1] == 56);
    assert(test7_arr[2] == 987);
//test fail
    int test8_arr[3] = {34567898,765,234};
    zeroesToFives(test1_arr, 3);
    assert(test8_arr[0] == 123456786);
    assert(test8_arr[1] == 765);
    assert(test8_arr[2] == 234);
//test fail
    int test9_arr[3] = {-8762,45123,-112345};
    zeroesToFives(test1_arr, 3);
    assert(test9_arr[0] == 2345);
    assert(test9_arr[1] == 12345);
    assert(test9_arr[2] == 98765);
//test pass
    int test10_arr[3] = {-1,-56,-987};
    zeroesToFives(test1_arr, 3);
    assert(test10_arr[0] == -1);
    assert(test10_arr[1] == -56);
    assert(test10_arr[2] == -987);
}