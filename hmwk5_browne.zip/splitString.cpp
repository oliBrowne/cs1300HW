#include <iostream>
#include <iomanip>
#include <sstream>

using namespace std;

int split(string input_string, char seperator, string arr[], int size)
{
    string word;
    int count = 0;
    //loops to the lenght
    for(int i = 0; i < input_string.length();i++)
    {
        if(input_string[i] == seperator)
        {
            arr[count] = word;
            word.clear();
            count++;
            i++;
        }
        // adds the strings into the array char by char 
        word = word + input_string[i];
        
        
    }
    arr[count] = word;
    //checks if they are a special case
    if(count >= size)
    {
        return -1;
    }
    else if(input_string == "")
    {
        return 0;
    }
    else;
    return count + 1;
}
string printArray(string input[],int size)
{
    for(int i = 0; i < size; i++)
    {
        cout << input[i] << endl;
    }
}
int main()
{
string testcase = "ABCDEFG";
char separator = ' ';
int size = 3;
string arr[size];
// numSplits is the value returned by split
int numSplits = split(testcase, separator, arr, size);
cout << "Function returned value: " << numSplits << endl;
cout << "arr[0]:"<< arr[0] << endl;
// test that the function returns a value
string testcase = "";
char separator = ' ';
// numSplits is the value returned by split
int numSplits = split(testcase, separator, arr, sizeof(arr)/sizeof(string));
cout << "Function returned value: " << numSplits << endl;


string testcase = "ABCD EFG";
char separator = ' ';
int size = 2;
// numSplits is the value returned by split
int numSplits = split(testcase, separator, arr, size);
cout << "Function returned value: " << numSplits << endl;

string testcase = "cityA,cityB,cityC,cityD";
char separator = ',';
int size = 3;
// numSplits is the value returned by split
int numSplits = split(testcase, separator, arr, size);
cout << "Function returned value: " << numSplits << endl;


}