#include <iostream>
#include <iomanip>
using namespace std;

bool insertAfter(string inputStrings[], int numElements, int size, int index , string stringToInsert)
{
    if (numElements == size || index >= size)
    {
        return 0;
    }
    else;
    {
        
        for (int i = size-1 ; i > index+1 ; i--)
        {
            inputStrings[i] = inputStrings[i - 1];
        
        }
        inputStrings[index + 1] = stringToInsert;
    }
    return inputStrings;
}

int secondPlace(string input_strings[], string string_to_insert, string  string_to_find, int numElements, int size, int count)
{
    //special case filter
    if ( numElements + count > size)
    {
        return numElements;
    }
    else;
    {
        //loop to size
        for(int i = 0; i <= size; i++)
        {
            // checks where taget is 
            if(input_strings[i] == string_to_find)
            {
              insertAfter(input_strings, numElements, size, i, string_to_insert);  
            }
        }
        //valueeeeeeeee
        return numElements + count;
    }
}
string printArray(string input[],int size)
{
    for(int i = 0; i < size; i++)
    {
        cout << input[i] << endl;
    }
}
int main()
{
    // test case 1
int size = 5;
int count = 1;
string inputStrings[size] = {"clefairy", "meowth", "snorlax"};
int numElements = 3;
string stringToInsert = "charizard";
string stringToFind = "meowth";
// updating numElements with the updated value returned by secondPlace
numElements = secondPlace(inputStrings, stringToInsert, stringToFind, numElements, size, count);
// print numElements
cout << "Function returned value: " << numElements << endl;
// print array contents
printArray(inputStrings, size);
}
