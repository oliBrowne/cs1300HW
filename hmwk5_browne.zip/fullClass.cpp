#include <iostream>
#include <iomanip>
using namespace std;

int fullClass(bool classroom[][4], int rows , int waitlist)
{
    //takes the rows in loop
    for (int i = 0; i < rows; i++)
    {
        //value loop
        for (int j = 0; j < 4; j++)
        {
            //changes values
            if(classroom[i][j] == 0 )
            {
                if(waitlist > 0 )
                {
                    classroom[i][j] = 1;
                    waitlist--;
                }
            }
            cout << classroom[i][j];
        }
        cout << endl;
    }
    cout << "Remaining Students: " << waitlist << endl;
    
    return waitlist;
}
int main ()
{
    bool classroom[4][4] = {{0, 1, 1, 1},
			{0, 0, 0, 0},
			{1, 1, 0, 0},
			{0, 1, 0, 1}};
int waitlist = 6;
fullClass(classroom, 4, waitlist);

bool classroom[4][4] = {{0, 1, 1, 1},
{0, 0, 0, 0},
{1, 1, 0, 0},
{0, 1, 0, 1}};
int waitlist = 6;
fullClass(classroom, 4, waitlist);

bool classroom[1][4] = {{1, 1, 1, 1}};
int waitlist = 6;
fullClass(classroom, 1, waitlist);

bool classroom[0][4] = {};
int waitlist = 6;
fullClass(classroom, 0, waitlist);
}
